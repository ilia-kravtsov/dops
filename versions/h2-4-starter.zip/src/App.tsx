import React, {useState} from 'react';
import './App.css';
import {Site} from "./components/Site";


function App() {
    return (
        <div>
            <Site/>
        </div>
    );
}


export default App;
